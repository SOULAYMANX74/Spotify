<?php
require '../main.php';
header("location: ".$bm->EXIT_LINK);
?>